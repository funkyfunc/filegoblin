The files are organized into directories: 
- sections/
    This directory contains LaTeX files for each section in the manuscript. 
- tables/
    The directory includes tables for reporting statistics or downstream results.
- figures/
    A directory to store figures if any.


  https://aclrollingreview.org/cfp
  https://aclrollingreview.org/authorchecklist
  https://aclrollingreview.org/submissionform